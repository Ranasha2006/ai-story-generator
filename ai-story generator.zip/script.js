const chatBody = document.querySelector(".chat-body");
const messageInput = document.querySelector(".message-input");
const sendMessageButton = document.querySelector("#send-message");

/* ==========================
   GEMINI API CONFIG
========================== */

const API_KEY = "YOUR API_KEY";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${API_KEY}`;

const chatHistory = [];
const initialInputHeight = messageInput.scrollHeight;

/* ==========================
   CREATE MESSAGE ELEMENT
========================== */

const createMessageElement = (content, ...classes) => {
  const div = document.createElement("div");
  div.classList.add("message", ...classes);
  div.innerHTML = content;
  return div;
};

/* ==========================
   GENERATE BOT RESPONSE
========================== */

const generateBotResponse = async (incomingMessageDiv) => {

  const messageElement = incomingMessageDiv.querySelector(".message-text");

  /* RANDOM SEED FOR DIFFERENT STORIES */

  const randomSeed = Math.floor(Math.random() * 100000000);
  const timestamp = Date.now();

  /* API REQUEST */

  const requestOptions = {
    method: "POST",
    headers: { "Content-Type": "application/json" },

    body: JSON.stringify({
      contents: chatHistory,

      generationConfig: {
        temperature: 1.6,
        topP: 0.95,
        maxOutputTokens: 500
      },

      systemInstruction: {
        parts: [
          {
            text: `Create a completely unique short story every time.
            Do not repeat plots or sentences.
            Use creative twists, different settings, and unexpected endings.
            Random seed: ${randomSeed}
            Timestamp: ${timestamp}`
          }
        ]
      }
    })
  };

  try {

    /* CONSOLE LOG WHEN API REQUEST STARTS */

    console.log("📡 Gemini API request sent at:", new Date().toLocaleTimeString());
    console.log("Request Body:", requestOptions);

    const response = await fetch(API_URL, requestOptions);

    const data = await response.json();

    /* CONSOLE LOG WHEN RESPONSE RECEIVED */

    console.log("✅ Gemini API response received");
    console.log("Response Data:", data);

    if (!response.ok) throw new Error(data.error.message);

    const apiResponseText = data.candidates[0].content.parts[0].text
      .replace(/\*\*(.*?)\*\*/g, "$1")
      .trim();

    messageElement.innerText = apiResponseText;

    /* SAVE BOT RESPONSE */

    chatHistory.push({
      role: "model",
      parts: [{ text: apiResponseText }]
    });

  } catch (error) {

    /* ERROR LOG */

    console.error("❌ Gemini API Error:", error);

    messageElement.innerText = error.message;
    messageElement.style.color = "#ff0000";

  } finally {

    incomingMessageDiv.classList.remove("thinking");

    chatBody.scrollTo({
      top: chatBody.scrollHeight,
      behavior: "smooth"
    });
  }
};

/* ==========================
   HANDLE USER MESSAGE
========================== */

const handleOutgoingMessage = (e) => {

  e.preventDefault();

  const userMessage = messageInput.value.trim();
  if (!userMessage) return;

  messageInput.value = "";

  const messageContent = `<div class="message-text"></div>`;

  const outgoingMessageDiv = createMessageElement(
    messageContent,
    "user-message"
  );

  outgoingMessageDiv.querySelector(".message-text").textContent = userMessage;

  chatBody.appendChild(outgoingMessageDiv);

  /* SAVE USER MESSAGE */

  chatHistory.push({
    role: "user",
    parts: [{ text: userMessage }]
  });

  chatBody.scrollTo({
    top: chatBody.scrollHeight,
    behavior: "smooth"
  });

  setTimeout(() => {

    const messageContent = `
    <svg class="bot-avatar" xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 1024 1024">
      <path d="M738.3 287.6H285.7c-59 0-106.8 47.8-106.8 106.8v303.1c0 59 47.8 106.8 106.8 106.8h81.5v111.1l166.9-110.6h159.2c59 0 106.8-47.8 106.8-106.8V394.5c0-59-47.8-106.9-106.8-106.9z"></path>
    </svg>

    <div class="message-text">
      <div class="thinking-indicator">
        <div class="dot"></div>
        <div class="dot"></div>
        <div class="dot"></div>
      </div>
    </div>`;

    const incomingMessageDiv = createMessageElement(
      messageContent,
      "bot-message",
      "thinking"
    );

    chatBody.appendChild(incomingMessageDiv);

    chatBody.scrollTo({
      top: chatBody.scrollHeight,
      behavior: "smooth"
    });

    generateBotResponse(incomingMessageDiv);

  }, 600);
};

/* ==========================
   EVENT LISTENERS
========================== */

sendMessageButton.addEventListener("click", handleOutgoingMessage);

messageInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    handleOutgoingMessage(e);
  }
});